﻿using System;
/*nt asosiy = 516;
float birinchi = 151.525f;
double ikkinchi = 1.4;
decimal uchinchi = 151.525M;
Console.WriteLine($"agar {asosiy} ga {birinchi} ni qo'shsak, {asosiy+birinchi} Hosil bo'ladi");
Console.WriteLine($"agar {birinchi}ga {ikkinchi} ga bo'lsak, {birinchi / ikkinchi} hosil bo'ladi ");
Console.WriteLine($"agar {birinchi}ni {ikkinchi}ga ko'paytirsak,   {birinchi * ikkinchi} hosil bo'ladi");
Console.WriteLine($"Aytgancha, bizda decimal ishlagan son bor. u {uchinchi}");
float f1 = 35e3F;
double d1 = 12E4D;
Console.WriteLine(f1);
Console.WriteLine(d1);*/
/*float pi = 3.14f;
double bigPi = pi;
Console.WriteLine(pi);
Console.WriteLine(bigPi);    
short age = 22;
decimal deciAge = age;
Console.WriteLine(age);
Console.WriteLine(deciAge);
Console.WriteLine(deciAge.ToString());
Console.WriteLine(pi);
long FloraTypes = 3222;
int SmallFlora = (int)FloraTypes;
Console.WriteLine(SmallFlora+"\n\n skjd");
int randomNumber = Convert.ToInt32("23");
Console.WriteLine(randomNumber);*/
internal class Program
{
    private static void Main(string[] args)
    {
        int yoshKesha = 10;

        Console.WriteLine($"Salom. Mening ismim Kesha. Men {yoshKesha} yoshdaman. \n Iltimos, yoshingizni kiriting:");
        string userInput = Console.ReadLine();

        if (int.TryParse(userInput, out int yoshUser))
        {
            Console.WriteLine($"Tushinarli, siz {yoshUser} yoshdasiz. \n Demak, siz {2023 - yoshUser} yil tug'ilgansiz");
            Console.WriteLine("Davom etish uchun [ENTER] tugmasini bosing");
            Console.ReadLine();
            Console.WriteLine($"Ikkalamizning yoshlarimiz o'rtasidagi farq: {yoshUser-yoshKesha}");
            Console.WriteLine($"Agar sizni yoshingizni meni yoshimga bo'lsak, {yoshUser/yoshKesha} xosil bo'ladi, Qoldiq esa {yoshUser%yoshKesha}");
            Console.WriteLine("Dasturni yakunlash uchun [ENTER] tugmasini bosing");
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Noto'g'ri format! Iltimos, raqam kiriting.");
        }

    }
}